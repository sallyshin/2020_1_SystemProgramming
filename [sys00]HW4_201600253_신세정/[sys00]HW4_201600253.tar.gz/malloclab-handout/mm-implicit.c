/*
 * mm-implicit.c - an empty malloc package
 *
 * NOTE TO STUDENTS: Replace this header comment with your own header
 * comment that gives a high level description of your solution.
 *
 * @id : 201600253 
 * @name : 신세정
 */
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "mm.h"
#include "memlib.h"

/* If you want debugging output, use the following macro.  When you hand
 * in, remove the #define DEBUG line. */
#define DEBUG
#ifdef DEBUG
# define dbg_printf(...) printf(__VA_ARGS__)
#else
# define dbg_printf(...)
#endif


/* do not change the following! */
#ifdef DRIVER
/* create aliases for driver tests */
#define malloc mm_malloc
#define free mm_free
#define realloc mm_realloc
#define calloc mm_calloc
#endif /* def DRIVER */

/* single word (4) or double word (8) alignment */
#define ALIGNMENT 8

/* rounds up to the nearest multiple of ALIGNMENT */
#define ALIGN(p) (((size_t)(p) + (ALIGNMENT-1)) & ~0x7)


#define WSIZE 4
#define DSIZE 8
#define CHUNKSIZE (1 << 12)
#define OVERHEAD 8
#define MAX(x, y)((x) > (y) ? (x) : (y))
#define PACK(size, alloc) ((size) | (alloc))
#define GET(p)(*(unsigned int *)(p))
#define PUT(p, val)(*(unsigned int *)(p) = (val))
#define GET_SIZE(p) (GET(p) & (~0x7))
#define GET_ALLOC(p) (GET(p) & 0x1)
#define HDRP(bp)((char *)(bp) - WSIZE) 
#define FTRP(bp) ((char*)(bp) + GET_SIZE(HDRP(bp)) - DSIZE)
#define NEXT_BLKP(bp) ((char*)(bp) +GET_SIZE((char * )(bp) -WSIZE))
#define PREV_BLKP(bp) ((char*)(bp)- GET_SIZE((char * )(bp) -DSIZE))

int mm_init(void);
void *malloc(size_t size);
static char *heap_listp = 0;
static void *coalesce(void *bp);
static void place(void *bp,size_t asize);
static void *extend_heap(size_t words);
static void *find_fit(size_t asize);
void *realloc(void *oldptr, size_t size);
void free(void *bp);

/*
 * Initialize: return -1 on error, 0 on success.
 */
int mm_init(void) {

	/* 메모리 시스템에서 4워드를 가져와 
	 * 빈 가용리스트를 만들 수 있도록 초기화
	 */
	if((heap_listp = mem_sbrk(4 * WSIZE)) == NULL)
		return -1;

	PUT(heap_listp, 0);
	PUT(heap_listp + WSIZE, PACK(OVERHEAD, 1));
	PUT(heap_listp + DSIZE, PACK(OVERHEAD, 1));
	PUT(heap_listp + WSIZE + DSIZE, PACK(0, 1));
	heap_listp += DSIZE;

	/*힙을 chunksize바이트로 확장하고 초기 가용블록 생성*/
	if((extend_heap(CHUNKSIZE / WSIZE)) == NULL)
		return -1;

    return 0;
}

/*
 * malloc
 */
/*size바이트 메모리 블록 요청*/
void *malloc (size_t size) {
    size_t asize; // 추가 block size
	size_t extendsize; // 안맞을때 늘릴 heap size
	char *bp;

	if(size == 0){ // size가 0이면 요청 무시
		return NULL;
	}

	if(size <= DSIZE){ 
		asize = 2 * DSIZE; 
	}
	// 8바이트 넘으면 오버헤드 바이트 내에 더하고인접  8의 배수로 반올림
	else{
		asize = DSIZE * ((size + (DSIZE) + (DSIZE - 1))/DSIZE);
	}
	
	// 사용할 수 있는 블록을 리스트에서 검색
	if((bp = find_fit(asize)) != NULL){
		place(bp, asize);
		return bp;
	}
	//힙을 새로운 가용 블록으로 확장
	extendsize = MAX(asize, CHUNKSIZE);
	
	if((bp = extend_heap(extendsize/WSIZE)) == NULL){
		return NULL;
	}
	place(bp, asize);
	return bp;
}

static void *coalesce(void *bp){
	
	// 이전 블럭 할당? 1 : 0 
	size_t prev = GET_ALLOC(FTRP(PREV_BLKP(bp)));
	// 다음 블럭 할당? 1 : 0
	size_t next = GET_ALLOC(HDRP(NEXT_BLKP(bp)));
	// 현재 블럭 크기
	size_t size = GET_SIZE(HDRP(bp));

	/* 
	 * case 1 :  이전블럭, 다음블럭 최하위bit 둘다1인경우1( 할당)
	 * 			블럭 병합 없이 bp return 
	 */
	if(prev == 1 && next == 1){
		return bp;
	}

	/*
	 * case 2 : 이전 블럭 최하위 bit 1(할당), 다음 블럭의 것은  0(비할당)
	 * 			다음 블럭과 병합 한 뒤 bp return
	 */
	else if(prev == 1 && next == 0){
		size += GET_SIZE(HDRP(NEXT_BLKP(bp)));
		PUT(HDRP(bp), PACK(size, 0)); 
		PUT(FTRP(bp), PACK(size, 0));
		return bp;
	}
	/*
	 * case 3 : 이전 블럭 최하위 bit 0(비할당), 다음 블럭의 것은 1(할당)
	 * 			이전 블럭과 병합하고 새로운 bp return
	 */
	else if(prev == 0 && next == 1){
		size += GET_SIZE(HDRP(PREV_BLKP(bp)));
		PUT(FTRP(bp), PACK(size, 0)); 
		PUT(HDRP(PREV_BLKP(bp)), PACK(size , 0));
		bp = PREV_BLKP(bp);
		return bp;
	}
	/*
	 * case 4 : 이전 블럭 최하위 bit 0(비할당), 다음 블럭의 것도 0 (할당)
	 * 			이전 블럭, 현재 블럭 ,다음 블럭 모두 병합하고 새로운 bp return
	 */
	else if(prev == 0 && next == 0){
		size += GET_SIZE(HDRP(PREV_BLKP(bp))) + GET_SIZE(FTRP(NEXT_BLKP(bp)));
		PUT(HDRP(PREV_BLKP(bp)), PACK(size, 0));
		PUT(FTRP(NEXT_BLKP(bp)), PACK(size, 0));
		bp = PREV_BLKP(bp);
		return bp;
	}
	//각 조건문마다 return bp 해줬습니다.
}


/*
 * bp 위치에 asize 크기의 메모리를 위치시켜줌
 */
static void place(void *bp, size_t asize){
	// 1. 블록을 가용 블록 시작부분에 배치해 나머지 크기가 최소 블록 크기와 같거나 크면 분할해주는데
	// 2. 이를 다음 이동 전에 새롭게 할당한 블록을 배치
	size_t cursize = GET_SIZE(HDRP(bp));

	if((cursize - asize) >= (2 * DSIZE)){ // 1번 조건
		// 2번 조건
		PUT(HDRP(bp), PACK(asize, 1));
		PUT(FTRP(bp), PACK(asize, 1));

		bp = NEXT_BLKP(bp); // 다음 블록으로
		
		// 나머지 크기 할당
		PUT(HDRP(bp), PACK(cursize - asize, 0));
		PUT(FTRP(bp), PACK(cursize - asize, 0));
	}
	else{
		// 같은 경우엔 분할 하지 않고 전체 할당
		PUT(HDRP(bp), PACK(cursize, 1));
		PUT(FTRP(bp), PACK(cursize, 1));
	}	
}

/*
 * 요청 받은 크기의 빈 블록을 만들어 줌. 
 * 이전 block을 검사하여 case별로 free 시켜주도록 구현
 */
static void *extend_heap(size_t words){
	char *ptr;
	size_t size;

	/* 요청한 크기를 인접 2words배수로 반올림하며,
	 * 그 후 메모리 시스템으로부터 추가 힙공간 요구
	 */
	if((words % 2) == 1){
		size = (words + 1) * WSIZE;
	}
	else {
		size = words * WSIZE;
	}
	
	
	if((long)(ptr = mem_sbrk(size)) == -1){
		return NULL;
	}

	// header 와 footer 초기화
	PUT(HDRP(ptr), PACK(size, 0));
	// header 블록 free
	PUT(FTRP(ptr), PACK(size, 0));
	// footer 블록 free
	PUT(HDRP(NEXT_BLKP(ptr)), PACK(0, 1));

	// 이전 힙이 가용 블록으로 끝났으면
	// 두개의 가용 블록을 통합하기위해
	// coalesce를 호출하고 통합된 블록의 포인터를 반환한다.
	return coalesce(ptr);
}

/*
 * free block을 검색. 
 * First, Next, Best fit 알고리즘 중하나를 
 * 선택해서 구현
 */
static void *find_fit(size_t asize){
	//First fit이 제일 간단하고 빠르다고 해서 선택
	
	// 리스트 첫부분 검색
	void *ptr;

	// 검색 하면서 전달된 인자만큼 크기의 블록을 찾는다.
	// 이는 반복문으로 차례로 찾으면 된다.
	for(ptr = heap_listp; GET_SIZE(HDRP(ptr)) > 0; ptr = NEXT_BLKP(ptr)){
		if(GET_ALLOC(HDRP(ptr)) == 0 && (asize <= GET_SIZE(HDRP(ptr)))){
			return ptr;
		}
	}
	return NULL;
}


/*
 * free
 */
void free (void *bp){
	if(bp == 0) { // 잘못된 요청이면 이전 프로시저로 return
		return;
	}

	//bp의 header에서 블록 size를 가져온다
	size_t size = GET_SIZE(HDRP(bp));

	//header에 블록 size와 alloc = 0을 저장한다
	PUT(HDRP(bp), PACK(size, 0));
	//footer에 블록 size와 alloc = 0을 저장한다
	PUT(FTRP(bp), PACK(size, 0));

	coalesce(bp);
}

/*
 * realloc - you may want to look at mm-naive.c
 */
void *realloc(void *oldptr, size_t size) {
	size_t oldsize;
	void *newptr;

	if(size == 0){
		free(oldptr);
		return 0;
	}

	if(oldptr == NULL){
		return malloc(size);
	}

	newptr = malloc(size);

	if(!newptr){
		return 0;
	}

	oldsize = GET_SIZE(oldptr);
	
	if(size < oldsize) {
		oldsize = size;
	}
	memcpy(newptr, oldptr, oldsize);

	free(oldptr);

    return newptr;
}

/*
 * calloc - you may want to look at mm-naive.c
 * This function is not tested by mdriver, but it is
 * needed to run the traces.
 */
void *calloc (size_t nmemb, size_t size) {
    return NULL;
}


/*
 * Return whether the pointer is in the heap.
 * May be useful for debugging.
 */
static int in_heap(const void *p) {
    return p < mem_heap_hi() && p >= mem_heap_lo();
}

/*
 * Return whether the pointer is aligned.
 * May be useful for debugging.
 */
static int aligned(const void *p) {
    return (size_t)ALIGN(p) == (size_t)p;
}

/*
 * mm_checkheap
 */
void mm_checkheap(int verbose) {
}
