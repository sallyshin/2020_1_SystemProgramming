/*
 * mm-explicit.c - an empty malloc package
 *
 * NOTE TO STUDENTS: Replace this header comment with your own header
 * comment that gives a high level description of your solution.
 *
 * @id : 201600253
 * @name : 신세정 
 */
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "mm.h"
#include "memlib.h"

/* If you want debugging output, use the following macro.  When you hand
 * in, remove the #define DEBUG line. */
#define DEBUG
#ifdef DEBUG
# define dbg_printf(...) printf(__VA_ARGS__)
#else
# define dbg_printf(...)
#endif


/* do not change the following! */
#ifdef DRIVER
/* create aliases for driver tests */
#define malloc mm_malloc
#define free mm_free
#define realloc mm_realloc
#define calloc mm_calloc
#endif /* def DRIVER */

/* single word (4) or double word (8) alignment */
#define ALIGNMENT 8

/* rounds up to the nearest multiple of ALIGNMENT */
#define ALIGN(p) (((size_t)(p) + (ALIGNMENT-1)) & ~0x7)

#define ALIGNMENT	8
#define HDRSIZE		4
#define FRTSIZE 	4
#define WSIZE 		4
#define DSIZE 		8
#define CHUNKSIZE 	(1<<12)
#define MINIMUM		24 // 최소 블록 크기
#define OVERHEAD 	8

#define MAX(x, y) ((x) > (y)? (x) : (y))
#define MIN(x, y) ((x) < (y)? (x) : (y))

#define PACK(size, alloc) ((unsigned)((size) | (alloc)))

#define GET(p) 		(*(unsigned *)(p))
#define PUT(p, val)	(*(unsigned *)(p) = (unsigned)(val))
#define GET8(p)		(*(unsigned long *)(p))
#define PUT8(p, val)(*(unsigned long *)(p) = (unsigned long)(val))

#define GET_SIZE(p)	(GET(p) & (~0x7))
#define GET_ALLOC(p) (GET(p) & 0x1)

#define HDRP(bp) 	((void *)(bp) - WSIZE)
#define FTRP(bp)    ((void *)(bp) + GET_SIZE(HDRP(bp)) - DSIZE)

#define NEXT_BLKP(bp)((void *)(bp) + GET_SIZE(HDRP(bp)))
#define PREV_BLKP(bp)((void *)(bp) - GET_SIZE(HDRP(bp) - DSIZE))

#define NEXT_FREEP(bp)    (*(void **)(bp))
#define PREV_FREEP(bp)    (*(void **)(bp) + DSIZE)

#define NEXT_FREE_BLKP(bp)    ((char *)GET8(char *)(bp))
#define PREV_FREE_BLKP(bp)    ((char *)GET8(char *)(bp) + DSIZE)

#define NEXT_BLKP(bp)    ((char *)(bp) + GET_SIZE((char *)(bp) - WSIZE))
#define PREV_BLKP(bp)    ((char *)(bp) - GET_SIZE((char *)(bp) - DSIZE))

#define DEBUG

static void *extend_heap(size_t words);
static void place(void *bp, size_t asize);
static void *find_fit(size_t asize);
static void *coalesce(void *bp);
static void remove_block(void *bp);

static char *heap_listp = 0;
static char *free_listp = 0;

/*
 * Initialize: return -1 on error, 0 on success.
 */
int mm_init(void) {
    
	if((heap_listp = mem_sbrk(2 * MINIMUM)) == NULL){
		return -1;
	}

	PUT8(heap_listp, 0);
	PUT8(heap_listp + WSIZE, PACK(MINIMUM , 1));
	PUT8(heap_listp + DSIZE, 0);
    PUT8(heap_listp + DSIZE + WSIZE, 0);
	PUT8(heap_listp + MINIMUM, PACK(MINIMUM , 1));
	PUT8(heap_listp + WSIZE + MINIMUM, PACK(0, 1));

	free_listp = heap_listp + DSIZE;
 
	if(extend_heap(CHUNKSIZE / WSIZE) == NULL){
		return -1;
	}

	return 0;
}

/*
 * malloc : 해당 크기의 블록을 할당하고 정렬을 통해 블록의 크기 계산
 */
void *malloc (size_t size) {

	char *bp;
	size_t asize; // 조정된 블록 크기
	size_t extendsize; // 맞는 fit이 없으면 늘리는 힙의 양

	dbg_printf("malloc : start");

	if(heap_listp == 0){
		mm_init();
	}

	if(size == 0) { // size가 0일때는 무시한다
		return NULL;
	}

	// 블록의 크기 결정 : 오버헤드와 정렬을 위한 부분을 포함한 크기
	if(size <= DSIZE){
		asize = 2*DSIZE;
	}
	else{
		asize = DSIZE * ((size + (DSIZE) + (DSIZE - 1) / DSIZE));
	}
	dbg_printf("malloc : line %llu to %llu\n", size, asize);

	// 결정한 크기 asize에 맞는 블록을 리스트에서 찾은 뒤
	if(bp = find_fit(asize) != NULL){ 
		place(bp, asize); // 해당 위치에 할당
		return bp;
	}

	dbg_printf("malloc : extend");
	// free 리스트에서 찾지 못하면 
	// 힙을 늘려서할당해야한다
	extendsize = MAX(asize, CHUNKSIZE);

	if((bp = extend_heap(extendsize/ WSIZE)) == NULL) {
		dbg_printf("malloc : extend failed");
		return NULL;
	}

	dbg_printf("malloc : extend done");
	place(bp, asize);
	return bp;
}

/*
 * free : 주어진 블록을 반환
 * 블록을 valid리스트에 추가한다.
 * 블록 포인터를 사용해 해당 블록 hdr와 ftr의 allocated bit를 0으로 하고
 * 인접한 valid 블럭들과 합친다.
 */
void free (void *ptr) {
	// 포인터가 null 이면 바로 반환
    if(!ptr) return;

	size_t size = GET_SIZE(HDRP(ptr));

	dbg_printf("size is : %llu\n", size);
	PUT8(HDRP(ptr), PACK(size, 0)); // header와
	PUT8(FTRP(ptr), PACK(size, 0)); // footer을 비할당 상태 (0)으로 만든다

	//인접한 valid 블록이 있으면 연결
	coalesce(ptr);
	dbg_printf("after size is %llu\n", size);
}

/*
 * realloc - you may want to look at mm-naive.c
 */
void *realloc(void *oldptr, size_t size) {

	size_t oldsize;
	void *newptr;
	size_t asize = MAX(ALIGN(size) + DSIZE, MINIMUM);

	dbg_printf("original size is %llu\n", oldsize);
	dbg_printf("asize size is %llu\n", asize);

	if(size <= 0){
		free(oldptr);
		return 0;
	}
	if(oldptr == NULL){
		return malloc(size);
	}
	oldsize = GET_SIZE(HDRP(oldptr));

	dbg_printf("old size is %llu\n", oldsize);

	if(asize == oldsize){
		return oldptr;
	}
	if(asize <= oldsize){
		
		size = asize;
		
		if(oldsize - size <= MINIMUM){
			return oldptr;
		}
		PUT8(HDRP(oldptr), PACK(size, 1));
		PUT8(FTRP(oldptr), PACK(size, 1));
		PUT8(HDRP(NEXT_BLKP(oldptr)), PACK(oldsize - size, 1));
		free(NEXT_BLKP(oldptr));
		
		return oldptr;
	}
	
	newptr = malloc(size);

	dbg_printf("new size is %llu", size);

	if(newptr == 0){
		return 0;
	}
	if(size < oldsize){
		oldsize = size;
	}
	memcpy(newptr, oldptr, oldsize);

	free(oldptr);

    return newptr;
}

/*
 * extendHeap : valid 리스트 힙을 늘리고 이를 블록 포인터에 반환
 */
static void *extend_heap(size_t words){
	
	char *ptr; // 힙을 늘린 후 새로운 블록 포인터
	size_t size; // 힙 메모리의 사이즈

	dbg_printf("size is %llu\n", size);

	// 힙 크기를 짝수로 : 정렬 유지위해
	if((size % 2)== 1){
		size = words * WSIZE;
	}
	else {
		size = (words + 1) * WSIZE;
	}

	if(size < MINIMUM){
		size = MINIMUM;
	}

	// 메모리에 힙 공간 요청
	// 음수이면 아무것도 하지 않는다
	if((long)(ptr = mem_sbrk(size)) == -1){
		return NULL;
	}

	// valid 블록의 header와 footer, epilogue를 초기화해주고
	PUT8(HDRP(ptr), PACK(size, 0));
	PUT8(FTRP(ptr), PACK(size, 0));
	PUT8(HDRP(NEXT_BLKP(ptr)), PACK(0, 1));

	// 새롭게 요청된 valid 공간이 이전 블록 valid블록이었다면 합치기
	return coalesce(ptr);
}
/*
 * place : asize바이트 블록을 valid블록 시작 위치에 배치하고 필요하면 분할
 */
static void place(void *bp, size_t asize){
	
	size_t size = GET_SIZE(HDRP(bp));

	// 크기차가 최소 24바이트 이상이면 
	// 블록할당하고, 남는 부분분할해 valid 리스트에 추가
	// 그렇지 않으면 분할 할 필요가 없다
	
	dbg_printf("size is %llu\n", size);

	if((size - asize) >= MINIMUM){
		//블록 할당
		PUT8(HDRP(bp), PACK(asize, 1));
		PUT8(FTRP(bp), PACK(asize, 1));

		//valid리스트에서 해당 블록 삭제
		remove_block(bp);
		bp = NEXT_BLKP(bp);

		// 남는 공간 header와 footer 계산
		PUT8(HDRP(bp), PACK(size - asize, 0));
		PUT8(FTRP(bp), PACK(size - asize, 0));

		// 새로운 valid 블록을 인접 valid 블록과 병합해준다
		coalesce(bp);
	}
	else{
		// 블록 할당하고
		PUT8(HDRP(bp), PACK(size, 1));
		PUT8(FTRP(bp), PACK(size, 1));

		// 할당 받은 블록을 valid 리스트에서 없앤다
		remove_block(bp);
	}

	dbg_printf("new size is %llu\n", size);

}
/*
 * find_fit 
 */
static void *find_fit(size_t asize){
	void *ptr;

	// valid 리스트 처음부터 해당 크기보다 큰 블록을 찾도록 반복문을 사용
	// 가용 리스트 첫 부분을 가리키고 있는 free_listp사용
	// 종료 조건은 가용 리스트 제일 마지막은 할당된 최소 크기 블록이 있으므로,
	// 블록의 allocated bit가 0이 아닐 때로 설정한다
	for(ptr = free_listp; GET_ALLOC(HDRP(ptr)) == 0; ptr = NEXT_FREEP(ptr)){
		//반복문을 돌면서 적당한 크기 블록을 찾으면 해당 블록 포인터 반환하고 종료
		if(asize <= (size_t)GET_SIZE(HDRP(ptr))){
			return ptr;
		}
	}
	// 적당한 블록을 찾지 못하면 NULL리턴
	return NULL;
}

/*
 * coalesce
 */
static void *coalesce(void *bp){

    // 이전 블록과 다음 블록이 할당되어 있는지 알아보는 변수
    size_t prev = GET_ALLOC(FTRP(PREV_BLKP(bp))) || PREV_BLKP(bp) == bp;
    size_t next = GET_ALLOC(HDRP(NEXT_BLKP(bp)));
    size_t size = GET_SIZE(HDRP(bp));

	/*
     * case 1 :  이전블럭, 다음블럭 둘다1인경우1( 할당)인 경우
	 * 아무것도 하지 않고 그냥 해당 블록을 가용 리스트 맨 앞에 추가
     */

	/*
     * case 2 : 이전 블럭1(할당), 다음 블럭이 0( 가용)인 경우
     */
    if(prev == 1 && next == 0){
        size += GET_SIZE(HDRP(NEXT_BLKP(bp))); // 다음 블록 크기와 합체
       	remove_block(NEXT_BLKP(bp)); // 가용 리스트에서 해당 블록 삭제
		PUT8(HDRP(bp), PACK(size, 0)); // header와 
        PUT8(FTRP(bp), PACK(size, 0)); // footer 재설정
    }
    /*
     * case 3 : 이전 블럭 0(가용), 다음 블럭은 1(할당)인 경우
     */
    else if(prev == 0 && next == 1){
        size += GET_SIZE(HDRP(PREV_BLKP(bp)));
		bp = PREV_BLKP(bp);
		remove_block(bp);
        PUT8(FTRP(bp), PACK(size, 0));
        PUT8(HDRP(PREV_BLKP(bp)), PACK(size , 0));
	}
	 /*
      * case 4 : 이전 블럭 0(비할당), 다음 블럭 0 (할당)인 경우
      */
	else if(prev == 0 && next == 0){
        size += GET_SIZE(HDRP(PREV_BLKP(bp))) + GET_SIZE(FTRP(NEXT_BLKP(bp)));
        remove_block(PREV_BLKP(bp));
		remove_block(NEXT_BLKP(bp));
		bp = PREV_BLKP(bp);
		PUT8(HDRP(PREV_BLKP(bp)), PACK(size, 0));
        PUT8(FTRP(NEXT_BLKP(bp)), PACK(size, 0));
        
    }
     // case 1 여기서 구현 : bp가 가리키는 블록을 가용 리스트 맨 앞에 추가
	 PUT8(NEXT_FREEP(bp),free_listp); // 현재 bp의 next가 가용리스트 시작을 가리키게
	 PUT8(PREV_FREEP(free_listp), bp); // 가용리스트 처음의 prev가 현재 bp 가리키도록
	 PUT8(PREV_FREEP(bp),NULL); // 현재 bp의 prev가 NULL이 되도록 
	 free_listp = bp; // 가용 리스트의 청므이 bp를 가리키게

	 return bp;
}

 /*
  * removeBlock : 가용리스트에서 가용 블록 제거
  */
static void remove_block(void *bp){
    // 이전 블록 존재 : 이 블록 next를 현재의 next 가용 블록을 가리키게한다
    if(PREV_FREEP(bp)){
       PUT8(NEXT_FREEP(PREV_FREEP(bp)),NEXT_FREEP(bp));
    }
    // 이전 블록이 없으면 : 가용 리스트 처음이 다른 가용 블록 가리키게 한다
    else{
        // 현재 블록이 가용 리스트 맨 첫 블록이라는 뜻이므로
        // 가용 리스트 맨 처음을 가리키는 free_listp가
        // 제거하려는 다음 블록을 가리키게 한다
        free_listp = NEXT_FREEP(bp);
    }
    // 다음 블록의 prev는 bp의 prev가 가리키게 한다
    PUT8(PREV_FREEP(NEXT_FREEP(bp)), PREV_FREEP(bp));
}



/*
 * calloc - you may want to look at mm-naive.c
 * This function is not tested by mdriver, but it is
 * needed to run the traces.
 */
void *calloc (size_t nmemb, size_t size) {
    size_t new_size = nmemb * size;
	void *newptr;

	newptr = malloc(new_size);
	memset(newptr, 0, new_size);

	return newptr;
}


/*
 * Return whether the pointer is in the heap.
 * May be useful for debugging.
 */
static int in_heap(const void *p) {
    return p < mem_heap_hi() && p >= mem_heap_lo();
}

/*
 * Return whether the pointer is aligned.
 * May be useful for debugging.
 */
static int aligned(const void *p) {
    return (size_t)ALIGN(p) == (size_t)p;
}

/*
 * mm_checkheap
 */
void mm_checkheap(int verbose) {
}
